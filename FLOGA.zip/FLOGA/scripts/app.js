(function() {

  "use strict";

  angular
    .module('cloudMigration', ['ngMaterial', 'ui.bootstrap', 'ngBootbox'])
    .config(function($mdThemingProvider) {
      $mdThemingProvider.theme('default')
        .primaryPalette('teal')
        .accentPalette('orange');
        // $locationProvider.hashPrefix('');
    });
        
})();

