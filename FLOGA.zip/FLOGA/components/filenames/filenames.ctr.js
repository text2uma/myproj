(function() {

    "use strict";

    angular
        .module('cloudMigration')
        .controller('filenamesController', function($scope, $mdSidenav, $mdDialog, $mdToast, filenamesFactory, $ngBootbox) {

            filenamesFactory.getFilenames().then(function(data) {
// need to change data.data
                $scope.filenames = data.data;
                // $scope.categories = getCategories($scope.filenames);
                addContact($scope.filenames);
            });

            var contact = {
                name: "Chittoori Venkata Sai Sashank",
                phone: "(555) 555-5555",
                email: "venkatasaisashank@capitalone.com"
            };

            function showToast(message) {
                $mdToast.show(
                    $mdToast.simple()
                        .content(message)
                        .position('top, right')
                        .hideDelay(3000)
                );
            }

            $scope.openSidebar = function() {
                $scope.sidebarTitle = 'Add a Filename';
                $mdSidenav('left').open();
            };

            $scope.closeSidebar = function() {
                $scope.filename = {};
                $mdSidenav('left').close();
            };

            $scope.saveFilename = function(filename) {
                if(filename) {
                    $scope.filename.contact = contact;
                    $scope.filenames.push(filename);
                    $scope.filename = {};
                    $scope.closeSidebar();
                    showToast('filename Saved');
                }
            };

            $scope.editFilename = function(filename) {
                $scope.editing = true;
                $scope.sidebarTitle = 'Edit Filename';
                $scope.filename = filename;
                $mdSidenav('left').open();
            };

            $scope.saveEdit = function() {
                $scope.editing = false;
                // Need to clear the form after, or else it will be populated when we go to add new filenames
                $scope.filename = {};
                $mdSidenav('left').close();
                showToast('Edit Saved');
            };

            $scope.deleteFilename = function(event, filename) {
                var confirm = $mdDialog.confirm()
                    .title('Are you sure you want to delete ' + filename.file + '?')
                    .targetEvent(event)
                    .ok('Yes')
                    .cancel('No');
                $mdDialog.show(confirm).then(function() {
                    var index = $scope.filenames.indexOf(filename);
                    $scope.filenames.splice(index, 1);
                    showToast('Filename Deleted');
                }, function() {
                    $scope.status = filename.file + ' is still here.';
                });
            };
            $scope.statusCheck = "Pending";
            $scope.statusChange = function(event){
                var statusConfirm = $mdDialog.confirm()
                    .title('Are you sure you want to change the status ' + "Nebula-BuisinessMetada" + '?')
                    .targetEvent(event)
                    .ok('Yes')
                    .cancel('No');
                $mdDialog.show(statusConfirm).then(function() {
                    // var getMetadata = $mdDialog.prompt()
                    //     .title('Kindly provide metadata number')
                    //     .placeholder('Metadata #')
                    //     .targetEvent(event)
                    //     .ok('Yes')
                    //     .cancel('Not Having the number');
                    // $mdDialog.show(getMetadata).then(function(value) {
                    //     $scope.number = value;
                    //     $scope.statusCheck = "Complete";
                    // }, function() {
                    //     $scope.statusCheck = "Pending";
                    // });
                    $scope.showPrompt(event);
                }, function() {
                    $scope.statusCheck = "Pending";
                });
            }

            $scope.showPrompt = function(event){
                $ngBootbox.prompt('Kindly provide metadata number', 'number')
                .then(function(value) {
                        console.log(value);
                        $scope.statusCheck = "Complete";
                    },
                    function() {
                        //Confirm was cancelled, don't delete customer
                        console.log('Confirm was cancelled');
                        $scope.statusCheck = "Pending";
                    });
            }
        });

    // function getCategories(filenames) {
    //
    //     var categories = [];
    //
    //     angular.forEach(filenames, function(ad) {
    //       angular.forEach(ad.filenames, function(filename) {
    //         categories.push(category);
    //       });
    //     });
    //
    //     return _.uniq(categories);
    //   }

    function addContact(filenames) {
        var contact = {
            name: "Chittoori Venkata Sai Sashank",
            phone: "(555) 555-5555",
            email: "venkatasaisashank@capitalone.com"
        };
        angular.forEach(filenames, function(file) {
            file.contact = contact;
        });
    }

})();