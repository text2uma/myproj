(function() {

  "use strict";

  angular
    .module('cloudMigration')
    .factory('filenamesFactory', function($http) {

      function getFilenames() {
        return $http.get('data/filenames.json');
      }

      return {
          getFilenames: getFilenames
      }
      
    });
    
})();