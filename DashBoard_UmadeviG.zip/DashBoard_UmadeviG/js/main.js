/**
 * Main AngularJS Web Application
 */
var app = angular.module('capitalOneWebApp', [
  'ngRoute'
]);

/**
 * Configure the Routes
 */
app.config(['$routeProvider', function ($routeProvider) {
  $routeProvider
    // Home
    .when("/", {templateUrl: "partials/home.html", controller: "PageCtrl"})
    // Pages
    .when("/about", {templateUrl: "partials/about.html", controller: "PageCtrl"})
    .when("/faq", {templateUrl: "partials/faq.html", controller: "PageCtrl"})
    .when("/dashboard", {templateUrl: "partials/dashboard.html", controller: "PageCtrl"})
    .when("/services", {templateUrl: "partials/services.html", controller: "PageCtrl"})
    .when("/contact", {templateUrl: "partials/contact.html", controller: "PageCtrl"})
    // Blog
    .when("/blog", {templateUrl: "partials/blog.html", controller: "BlogCtrl"})
    .when("/blog/post", {templateUrl: "partials/blog_item.html", controller: "BlogCtrl"})
    // else 404
    .otherwise("/404", {templateUrl: "partials/404.html", controller: "PageCtrl"});
}]);

/**
 * Controls the Blog
 */
app.controller('BlogCtrl', function (/* $scope, $location, $http */) {
  console.log("Blog Controller reporting for duty.");
});

/**
 * Controls all other Pages
 */
app.controller('PageCtrl', function ($scope,$interval) {
  console.log("Page Controller reporting for duty.");
  
		  $scope.basicDashboard = {
			  price : null,
			  projects : null,
			  storage : null,
			  users : null,
			  bandWidth : null
		  };
		  
		  $scope.plusDashboard = {
			  price : null,
			  projects : null,
			  storage : null,
			  users : null,
			  bandWidth : null
		  };
		  
		  $scope.premiumDashboard = {
			  price : null,
			  projects : null,
			  storage : null,
			  users : null,
			  bandWidth : null
		  };
		  
		  $scope.ultimateDashboard = {
			  price : null,
			  projects : null,
			  storage : null,
			  users : null,
			  bandWidth : null
		  };
  
		var data = [
			{  
			 "basicDashboard": {
				  "price" : "10",
				  "projects" : "5",
				  "storage" : "10",
				  "users" : "100",
				  "bandWidth" : "10",
			 }
			},
			{  
			 "plusDashboard" : {
				  "price" : "155",
				  "projects" : "55",
				  "storage" : "99",
				  "users" : "88",
				  "bandWidth" : "10",
			 }
			},
			{  
			"premiumDashboard" : {
				  "price" : "776",
				  "projects" : "45",
				  "storage" : "99",
				  "users" : "88",
				  "bandWidth" : "10",
			}
			  
			},
			{  
			  "ultimateDashboard" : {
				  "price" : "266",
				  "projects" : "75",
				  "storage" : "26",
				  "users" : "364",
				  "bandWidth" : "10",
			  }
			},
		]
	
		// angular.forEach(data, function(rec) {    					 
			 // $scope.basicDashboard.price = rec.price;
			 // $scope.basicDashboard.projects = rec.projects;
			 // $scope.basicDashboard.storage = rec.storage;
			 // $scope.basicDashboard.users = rec.users;
			 // $scope.basicDashboard.bandWidth = rec.bandWidth;
		// }); 
	
		 $scope.basicDashboard.price = data[0].basicDashboard.price;
		 $scope.basicDashboard.projects = data[0].basicDashboard.projects;
		 $scope.basicDashboard.storage = data[0].basicDashboard.storage;
		 $scope.basicDashboard.users = data[0].basicDashboard.users;
		 $scope.basicDashboard.bandWidth = data[0].basicDashboard.bandWidth;
		 
		 $scope.plusDashboard.price = data[1].plusDashboard.price;
		 $scope.plusDashboard.projects = data[1].plusDashboard.projects;
		 $scope.plusDashboard.storage = data[1].plusDashboard.storage;
		 $scope.plusDashboard.users = data[1].plusDashboard.users;
		 $scope.plusDashboard.bandWidth = data[1].plusDashboard.bandWidth;
		 
		 $scope.premiumDashboard.price = data[2].premiumDashboard.price;
		 $scope.premiumDashboard.projects = data[2].premiumDashboard.projects;
		 $scope.premiumDashboard.storage = data[2].premiumDashboard.storage;
		 $scope.premiumDashboard.users = data[2].premiumDashboard.users;
		 $scope.premiumDashboard.bandWidth = data[2].premiumDashboard.bandWidth;
		 
		 $scope.ultimateDashboard.price = data[3].ultimateDashboard.price;
		 $scope.ultimateDashboard.projects = data[3].ultimateDashboard.projects;
		 $scope.ultimateDashboard.storage = data[3].ultimateDashboard.storage;
		 $scope.ultimateDashboard.users = data[3].ultimateDashboard.users;
		 $scope.ultimateDashboard.bandWidth = data[3].ultimateDashboard.bandWidth;
  
	});